<?php

namespace app\Config;

class DatabaseConfig {

    // setting konfigurasi database
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "praktikum";
    public $port = 3306;
}